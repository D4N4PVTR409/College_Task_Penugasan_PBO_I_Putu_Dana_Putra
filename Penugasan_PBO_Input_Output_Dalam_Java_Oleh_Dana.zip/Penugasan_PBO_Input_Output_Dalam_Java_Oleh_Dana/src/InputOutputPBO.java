import  java.util.Scanner;
//Kita memasukkan atau mengimport class scanner seperti diatas, untuk bisa mendeklarasikan fungsi scan di dalam program.
public class InputOutputPBO {
    public static void main(String[] args) {
        //Sebelum kita membuat program ini, ada baiknya kita mengetahui apa saja elemen yang dibutuhkan,
        //Untuk menghitung BMI (Body Mass Index) atau yang disebut berat badan ideal.
        //Dalam hukum BMI sendiri sudah ada range yang menentukan berat badan ideal dari manusia.
        //Variabel yang kita butuhkan disini ada dua yaitu tinggi dan juga berat badan.
        //Perhitungannya adalah berat dibagi tinggi, yang dimana tinggi diubah menjadi satuan meter kuadrat atau m^2.

        Scanner keyboard = new Scanner(System.in); //Deklarasi untuk scanner yang kami buat untuk input jenis huruf.
        Scanner masuk = new Scanner(System.in); //Deklarasi untuk scanner yang kami buat untuk input jenis angka.
        String nama, alamat, jk; //Deklarasi untuk tipe data yang berbentuk huruf.
        int umur; //Deklarasi untuk tipe data yang berbentuk interger atau angka.
        float berat, tinggi, meter; //Deklarasi untuk tipe data float atau untuk bilangan desimal skala kecil.
        double bmi; //Deklarasi untuk tipe data double atau untuk bilangan desimal skala besar.

        //Dibawah ini adalah pembuatan tampilan program dan juga pendeklarasian scanner.
        System.out.println("+ + Penugasan Pemrograman Berorientasi Objek Mengenai Input Output + +");
        System.out.println("+ + Nama Kelompok + +");
        System.out.println("+ I Putu Dana Putra (1908561078)");
        System.out.println("+ Gede Brahmantara Adi Krisnayana (1908561075)");
        System.out.println("+ I Putu Hanggara Diatha (1908561083)");
        System.out.println("+ I Ketut Agus Pranata Muliawan (1908561086)");
        System.out.println("============================================");
        System.out.print("\n");
        System.out.println("Masukan: ");
        System.out.print("Nama: ");
        nama = keyboard.nextLine();
        System.out.print("JK: ");
        jk = keyboard.nextLine();
        System.out.print("Umur: ");
        umur = masuk.nextInt();
        System.out.print("Alamat: ");
        alamat = keyboard.nextLine();
        System.out.print("Tinggi Badan (cm): ");
        tinggi = masuk.nextFloat();
        System.out.print("Berat Badan (kg): ");
        berat = masuk.nextFloat();
        meter = tinggi / 100;
        System.out.print("\n");
        // Dibawah ini rumus untuk menampilkan perhitungan BMI.
        bmi = (berat / (meter * meter));
        //Dibawah ini adalah output dari simpanan yang sudah kita input.
        System.out.println("Nama: " + nama);
        System.out.println("JK: " + jk);
        System.out.println("Umur: " + umur);
        System.out.println("Alamat: " + alamat);
        System.out.println("Tinggi Badan (cm): " + tinggi);
        System.out.println("Berat Badan (kg) : " + berat);
        System.out.println(String.format("BMI (Body Mass Index) anda : %.2f", bmi));

        //Dibawah ini Percabangan IF
        if (bmi < 18.5) {
            System.out.println("Berat Badan Anda Kurus :( ");
        } else if (bmi <= 22.9) {
            System.out.println("SELAMAT BERAT BADAN ANDA NORMAL");
        } else if (bmi < 24.9) {
            System.out.println("Berat Badan Anda Menyatakan Bahwa Anda Gemuk, Ayo Berolah Raga ! ");
        } else {
            System.out.println("Huft Berat Badan Anda Menyatakan Bahwa Anda Obesitas, Ayo Hidup Sehat ! ");
        }

    }
}
