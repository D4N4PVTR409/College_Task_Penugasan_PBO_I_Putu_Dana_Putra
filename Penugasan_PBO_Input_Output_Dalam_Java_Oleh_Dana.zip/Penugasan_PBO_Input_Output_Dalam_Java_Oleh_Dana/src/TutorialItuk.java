public class TutorialItuk {
    public static void main(String[] args){
        System.out.println("Nama Saya Ituk dan NIM Saya 1908561086");
    }
}
