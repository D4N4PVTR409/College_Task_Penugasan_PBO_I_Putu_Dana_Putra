public class DemoKarakter {
    public static void main(String[] args){
        char ch1 = 65; // Menggunakan tipe data char dan disini menggunakan ASCII yaitu 65 dimana jika di convert menjadi A.
        char ch2 ='B'; // Mendeklarasikan tipe data char selanjutnya.
        System.out.println("ch1 = " +ch1); // Tampilan layar.
        System.out.println("ch2 = " +ch2); // Tampilan layar.
    }
}
