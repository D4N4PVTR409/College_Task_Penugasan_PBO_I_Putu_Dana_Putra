public class DemoBoolean {
    public static void main(String[] args) {
        boolean b; // Mengisi deklarasi boolean yaitu nanti ada true dan false.
        b = true; // Disini B sudah  di deklarasikan sebagai true.
        System.out.println("Nilai b = " + b);
        if (b) {
            System.out.println("Statement ke-1 dieksekusi"); // Karena B adalah true maka di eksekusilah perintah ini.
        }
        b = false; // Disini B sudah di deklarasikan sebagai false.
        System.out.println("Nilai b = " + b);
        if (b) {
            System.out.println("Statement ke-2 tidak dieksekusi"); // Karene B adalah false maka statement ini tidak di eksekusi.
        }
        if (!b) {
            System.out.println("Statement ke-3 dieksekusi"); // Karene B adalah false tapi perintah if itu berisi tanda seru,
            // yang berarti kebalikan atau negasi dari false dari B yaitu true, oleh karena itu statement ini di eksekusi.
        }
            System.out.println("5 <= 10 mengembalikan nilai " + (5 <= 10)); // Tampilan output otomatis boolean.
            System.out.println("4 > 6 mengembalikan nilai " + (4 > 6)); // Tampilan output otomatis dari boolean.
        }
    }
