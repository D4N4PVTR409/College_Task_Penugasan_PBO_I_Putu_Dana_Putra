public class Contohperhitungan {
    public static void main(String[] args){
        byte a = 1; // Ini adalah interger.
        short b = 2; // Ini juga adalah variabel interger.
        int c = 3,d; // Lalu c juga termasuk variabel interger.
        d = a+b+c; // Disebelah ini adalah pendeklarasian dari perintah yang di inginkan.
        System.out.println("Hasil = " +d); // Tampilan pada layar, +d disini memiliki maksud bahwa nilai d yang dimasukkan.
    }
}
