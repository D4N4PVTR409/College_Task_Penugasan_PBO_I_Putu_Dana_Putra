public class DemoKonversi {
    public static void main (String[] args){
        int a = 257; // Memberi masukan pada tipe data interger.
        double d = 274.5678; // Memberi masukan pada tipe data float.

        byte b;
        b = (byte) a; //Konversi Byte ke interger.
        System.out.println("Typecasting dari tipe int ke tipe byte");
        System.out.println("int : " +a);
        System.out.println("byte : " +b);

        int x;
        x = (int)d; //Konversi interger ke double.
        System.out.println("Typecasting dari tipe double ke tipe int");
        System.out.println("double : " +d);
        System.out.println("int : " +x);

        b = (byte)d; //Konversi byte ke double.
        System.out.println("Typecasting dari tipe double ke tipe byte");
        System.out.println("double : " +d);
        System.out.println("byte : "+b);
    }
}
