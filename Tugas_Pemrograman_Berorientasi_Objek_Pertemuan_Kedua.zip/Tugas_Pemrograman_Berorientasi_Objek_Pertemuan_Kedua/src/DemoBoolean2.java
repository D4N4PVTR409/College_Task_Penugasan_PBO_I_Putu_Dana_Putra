public class DemoBoolean2 {
    public static void main (String[] args){
        int index = 0; // Menentukan awal dari index itu adalah 0 dengan menggunakan tipe data interger.
        while (index < 5) { // Kalau index masih kurang dari 5 maka nilai akan bertambah satu.
            System.out.println ("Baris ke-" +(index+1));
            index++; // Perintah otomatis increment.
        }
    }
}
