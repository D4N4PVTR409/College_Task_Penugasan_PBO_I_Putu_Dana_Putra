public class LingkupVariabel {
    public static void main(String[] args){
        int a = 10;

        if (a>5) {
            int b = 15;
            System.out.println("Nilai a di dalam blok if : " +a);
            System.out.println("Nilai b di dalam blok if : " +b);
        }
        int b = 15;
        System.out.println("Nilai a di luar blok if : " +a);
        System.out.println("Nilai b di luar blok if : " +b);
    }
}
// Kenapa bisa error karena tidak ada variabel yang mengisi b pada perintah terakhir yang ada pada program,
// Itu kenapa kita harus mendeklarasikan satu variabel lagi yang mendeskripsikan variabel b untuk bisa menjalankan program.
