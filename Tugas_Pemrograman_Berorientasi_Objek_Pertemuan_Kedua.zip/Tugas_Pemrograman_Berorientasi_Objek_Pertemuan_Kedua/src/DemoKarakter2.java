public class DemoKarakter2 {
    public static void main(String[] args){
        char ch = 'A'; // Disini kita menggunakan tipe data char.
        System.out.println("ch = " +ch); // Tampilan layar pada tipe data char yang menampilkan huruf A.
        ch++; // Disini ada yang dimaksud increment dimana itu berfungsi untuk menambah satu angka dari variable yang dimaksud.
        System.out.println("ch = " +ch); // Tampilan layar pada increment.
    }
}
