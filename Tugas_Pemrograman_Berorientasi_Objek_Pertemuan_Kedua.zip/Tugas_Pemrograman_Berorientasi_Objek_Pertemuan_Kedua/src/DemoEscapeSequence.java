public class DemoEscapeSequence {
    public static void main(String[] args){
        System.out.print ("Hari\t\t: Jum\'at\n"); // Tampilan layar dengan menggunakan perintah print. Yang dimana print itu
        //mencetak tanpa adanya enter.
        System.out.print ("Tanggal\t\t: 1 Februari 1987\n"); //Tampilan layar dengan menggunakan perintah print.
    }
}
