public class KelilingLingkaran {
    public static void main(String[] args){
        double pi = 3.1416; // Disini ada double yang berarti sama dengan float tapi kapasitasnya lebih besar.
        double r = 2.12; // Disini ada variable double. Gunanya sama yaitu menampilkan bilangan riil.
        double keliling; // Pembuatan variable yang nanti akan di deklarasikan.
        keliling = 2*pi*r; // Rumus pendeklarasian.
        System.out.println("Keliling Lingkaran = " +keliling); // Tampilan layar.
    }
}
